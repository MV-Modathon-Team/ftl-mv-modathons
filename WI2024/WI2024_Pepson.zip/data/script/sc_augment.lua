script.on_internal_event(Defines.InternalEvents.GET_DODGE_FACTOR, function(ship, value)
    if ship:HasAugmentation("TEMPEST_LONG_RANGE") > 0 then value = value + 10 end

    return Defines.Chain.CONTINUE, value
end)
