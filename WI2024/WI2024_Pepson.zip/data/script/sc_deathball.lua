-- Maybe, the real lua tech were the friends we made along the way
-- If you are here you are probably looking to a curiosity or a need to understand how this black magic work
-- Apart from the EnergyBall instance called myBall (which is pretty funny) you won't find much joy in it
-- I'm not the best commenter, glhf

EnergyBall = {}
EnergyBall.__index = EnergyBall
local circle = Hyperspace.Resources:GetImageId("ship/ball.png")
local lightnings = {}
local energyBalls = {}
local toRemove = {}
local PICTURESIZE = 200 / 2
local RADIUS = 100
local DRIFT = 1
local secondPerHp = 4

local function vter(cvec)
    local i = -1
    local n = cvec:size()
    return function()
        i = i + 1
        if i < n then return cvec[i] end
    end
end

-- Couldn't corrupt chrono to put the GL_DrawCircle expose in 15.1
local function renderCircle(x, y, radius, color)
    if radius < 0 then radius = radius * -1 end
    local scale = radius / PICTURESIZE
    
    Graphics.CSurface.GL_PushMatrix()
    Graphics.CSurface.GL_Translate(x, y, 0)  -- Center translation
    Graphics.CSurface.GL_Scale(scale, scale, 0)
    
    local topLeftX = -PICTURESIZE
    local topLeftY = -PICTURESIZE
    Hyperspace.Resources:RenderImage(circle, topLeftX, topLeftY, 0, color, color.a, false)
    
    Graphics.CSurface.GL_PopMatrix()
end
 
local function createLightning(x, y, direction, maxAge, size, parentAge)
    local newLightning = {
        x = x,
        y = y,
        direction = direction,
        size = size or 1,
        age = parentAge or 0,  -- Inherit age if it's a branch
        maxAge = maxAge,
        pixels = {}
    }
    table.insert(lightnings, newLightning)
end
 
local function updateLightning(dt)
    local toRemove = {}
    for i, lightning in ipairs(lightnings) do
        if lightning.age < lightning.maxAge then
            lightning.age = lightning.age + dt
 
            -- Calculate color based on age
            local progress = lightning.age / lightning.maxAge
            local r = (0.1 + progress * 0.8)%1
            local g = (0.1 + progress * 0.8)%1
            local b = (0.5 + progress * 0.5)%1
            local a = (1 - progress)%1
 
            local dx = math.cos(lightning.direction) * lightning.size
            local dy = math.sin(lightning.direction) * lightning.size
            local newX = lightning.x + dx
            local newY = lightning.y + dy
 
            table.insert(lightning.pixels, { x = newX, y = newY, r = r, g = g, b = b, a = a})
 
            lightning.x = newX
            lightning.y = newY
 
 
            lightning.direction = lightning.direction + math.random() * 0.5 - 0.25 -- +/- 15 degrees
 
            -- Branching (increase chance with age)
            if math.random() < progress * 0.1 then -- 10% chance at max age
                local branchDirection = lightning.direction + math.random() * math.pi - math.pi/2
                createLightning(lightning.x, lightning.y, branchDirection, lightning.maxAge, lightning.size, lightning.age)
            end
        else
            table.insert(toRemove, i)
        end
    end
 
    for i = #toRemove, 1, -1 do
        table.remove(lightnings, toRemove[i])
    end
end
 
local function drawLightnings()
    for _, lightning in ipairs(lightnings) do
        for _, pixel in ipairs(lightning.pixels) do
            Graphics.CSurface.GL_DrawRect(pixel.x, pixel.y, lightning.size, lightning.size, Graphics.GL_Color(pixel.r, pixel.g, pixel.b, pixel.a))
        end
    end
end

function EnergyBall.new(x, y, radius, drift)
    local newEnergyBall = {}
    setmetatable(newEnergyBall, EnergyBall)

    newEnergyBall.currentShipId = 0
    newEnergyBall.x = x
    newEnergyBall.y = y
    newEnergyBall.radius = radius
    newEnergyBall.drift = drift or 5
    newEnergyBall.progress = 0
    newEnergyBall.particles = {}
    newEnergyBall.lightningAge = 0
    newEnergyBall.targetX = nil
    newEnergyBall.targetY = nil
    newEnergyBall.fired = false
    newEnergyBall.exploding = false
    newEnergyBall.explosionProgress = 0
    return newEnergyBall
end

function EnergyBall:Fire(targetX, targetY)
    self.targetX = targetX
    self.targetY = targetY
    self.fired = true
    Hyperspace.Sounds:PlaySoundMix("sc_tempest_fire", -1, false)
end

function EnergyBall:render(dt, paused)
    if self.fired then
        self.progress = 1
        if not paused then
            self.x = self.x + 5 -- Move to the right
            if self.x > 1200 then
                self.currentShipId = 1
                self.x = -250 -- Set to the left
                self.y = self.targetY
                return
            end
            if self.x >= self.targetX and self.currentShipId == 1 then
                self.exploding = true -- Start explosion process
                self.fired = false
                Hyperspace.ships.enemy.ship.hullIntegrity.first = 0
                Hyperspace.Sounds:PlaySoundMix("sc_tempest_impact", -1, false)
            end
        end
    end

    if self.exploding then
        self.progress = 1
        self.explosionProgress = self.explosionProgress + dt
        if self.explosionProgress < 4 then
            self.radius = self.radius - 5 -- Implosion that turns into expansion
        else
            self.exploded = true -- Mark for deletion
        end
    end

    local currentRadius = self.radius * self.progress 
    if self.currentShipId > 0 then currentRadius = currentRadius * 1.5 end

    -- Color fluctuation
    local shimmer = math.sin(os.clock()) * 10
    local color1 = Graphics.GL_Color(((95 + shimmer) / 255)%1, ((190 + shimmer) / 255)%1, ((225 + shimmer) / 255)%1, 200 / 255)
    local color2 = Graphics.GL_Color(((60 + shimmer) / 255)%1, ((90 + shimmer) / 255)%1, ((127 + shimmer) / 255)%1, 150 / 255)
    local color3 = Graphics.GL_Color(((30 + shimmer) / 255)%1, ((60 + shimmer) / 255)%1, ((90 + shimmer) / 255)%1, 200 / 255)

    -- Pulsation offsets (me when I put random number and see)
    local pulsation1 = math.sin(os.clock() * 2) * 10
    local pulsation2 = math.sin(os.clock() * 2 + 2) * 10
    local pulsation3 = math.sin(os.clock() * 2 + 4) * 10

    local driftX1 = math.random(-self.drift, self.drift)
    local driftY1 = math.random(-self.drift, self.drift)
    local driftX2 = math.random(-self.drift, self.drift)
    local driftY2 = math.random(-self.drift, self.drift)
    local driftX3 = math.random(-self.drift, self.drift)
    local driftY3 = math.random(-self.drift, self.drift)

    -- Draw the circles
    --Graphics.CSurface.GL_DrawCircle(self.x + driftX1, self.y + driftY1, currentRadius + pulsation1, color1)
    --Graphics.CSurface.GL_DrawCircle(self.x + driftX2, self.y + driftY2, currentRadius * 0.8 + pulsation2, color2)
    --Graphics.CSurface.GL_DrawCircle(self.x + driftX3, self.y + driftY3, currentRadius * 0.5+ pulsation3, color3)

    renderCircle(self.x + driftX1, self.y + driftY1, currentRadius + pulsation1, color1)
    renderCircle(self.x + driftX2, self.y + driftY2, currentRadius * 0.8 + pulsation2, color2)
    renderCircle(self.x + driftX3, self.y + driftY3, currentRadius * 0.5 + pulsation3, color3)

    -- Particle effects
    local numParticles = 20 * self.progress

    for i = 1, #self.particles do
        local particle = self.particles[i]
        if particle then
            particle.progress = particle.progress + 0.02
            if particle.progress > 1 then
                table.remove(self.particles, i)
            end
        end
    end

    for i = #self.particles + 1, numParticles do 
        local newParticle = { progress = 0 }
        table.insert(self.particles, newParticle)
    end

    for i = 1, #self.particles do 
        local particle = self.particles[i]
        local particleRadius = currentRadius * particle.progress
        local angle = math.random() * 2 * math.pi
        local particleX = self.x + math.cos(angle) * particleRadius + math.random(-self.drift, self.drift)
        local particleY = self.y + math.sin(angle) * particleRadius + math.random(-self.drift, self.drift)

        local particleAlpha = 255 * (1 - particle.progress) 
        local particleSize = 1 + 2 * particle.progress 

        local particleWhite = Graphics.GL_Color(255 / 255, 255 / 255, 255 / 255, (particleAlpha / 255)%1)
        --Graphics.CSurface.GL_DrawCircle(particleX, particleY, particleSize, particleWhite)
        renderCircle(particleX, particleY, particleSize, particleWhite)
    end

    -- Update lightning inside the energy ball
    if not self.fired and not self.exploding and math.random() < 0.05 then
        createLightning(self.x, self.y, math.random() * 2 * math.pi, 0.5 + 1 * self.progress, 1)
    end

    -- Draw the lightning inside the energy ball
    updateLightning(dt)
    if not self.fired then drawLightnings() end
end

script.on_render_event(Defines.RenderEvents.SHIP, function(ship) end, function(ship) 
    for _, myBall in pairs(energyBalls) do
        if myBall.currentShipId == ship.iShipId then
            myBall:render(Hyperspace.FPS.SpeedFactor/16, Hyperspace.App.gui.bPaused)
        end
    end
end)

local wait = false

script.on_internal_event(Defines.InternalEvents.SHIP_LOOP, function(ship)
    -- Welcome to if town
    local enemy = Hyperspace.ships.enemy

    for i = #toRemove, 1, -1 do
        wait = false
        table.remove(energyBalls, i)
        if enemy then enemy.ship.hullIntegrity.first = 0 end
    end
    toRemove = {}

    if ship.iShipId > 0 or ship.myBlueprint.blueprintName ~= "PLAYER_SHIP_SC_TEMPEST" or not ship.artillerySystems then return end

    if #energyBalls == 0 and not wait then
        local ball = EnergyBall.new(410, 230, RADIUS, DRIFT)
        table.insert(energyBalls, ball)
    end

    local arti = nil
    for art in vter(ship.artillerySystems) do
        arti = art.projectileFactory
    end

    if not enemy or (enemy and enemy.ship.hullIntegrity.first <= 0) or wait then 
        arti.cooldown.first = 0.1 
    end

    if enemy and enemy.ship.hullIntegrity.first > 0 then
        arti.blueprint.cooldown = enemy.ship.hullIntegrity.first * secondPerHp
    end

    for _, myBall in pairs(energyBalls) do
        myBall.progress = arti.cooldown.first / arti.cooldown.second
        if myBall.exploded or (not Hyperspace.App.gui.dangerLocation and myBall.currentShipId > 0) then table.insert(toRemove, myBall) end
        if myBall.progress >= 1 and enemy and enemy.ship.hullIntegrity.first > 0 then
            myBall:Fire(100, 100)
            arti.cooldown.first = 0
            wait = true
        end
    end
end)
