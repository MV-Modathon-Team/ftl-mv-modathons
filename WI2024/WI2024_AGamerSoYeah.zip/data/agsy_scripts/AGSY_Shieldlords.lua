local superShieldCap = 1

script.on_internal_event(Defines.InternalEvents.SHIP_LOOP, function(shipManager)
    if shipManager:HasAugmentation("AGSY_SHIELDLORDS") > 0 then
        local superShield = shipManager.shieldSystem.shields.power.super
        if superShield.second < superShieldCap then
            superShield.second = superShieldCap
        end
    end
end)

script.on_internal_event(Defines.InternalEvents.JUMP_ARRIVE, function(shipManager)
    if shipManager:HasAugmentation("AGSY_SHIELDLORDS") > 0 then
        local superShield = shipManager.shieldSystem.shields.power.super
        superShield.second = superShield.first + shipManager.shieldSystem:GetMaxPower()
        superShield.first = superShield.second
        superShieldCap = superShield.second
    end
end)