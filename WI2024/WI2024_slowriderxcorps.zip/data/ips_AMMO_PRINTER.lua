script.on_internal_event(Defines.InternalEvents.JUMP_LEAVE, function(ship)
  if ship:HasAugmentation("IPS_AMMO_PRINTER") > 0 then
    local ammoPrintValue = ship:GetAugmentationValue("IPS_AMMO_PRINTER")*math.max(0,math.min(1,(40-ship:GetMissileCount())/10))
    ship:ModifyMissileCount(ammoPrintValue//1 + ((math.random()<(ammoPrintValue%1)) and 1 or 0))
  end
end)

--Created by GC + Julk
--Current Code Behaviour: uses Aug Value to determine how many Missiles to generate by Jumping
--CURRENTLY: The Chance to Work is Maxed until 30 Missiles before decreasing Linearly, stopping at 40: ((math.random()<math.min((ammoPrintValue%1),(40-ship:GetMissileCount())/10)) and 1 or 0))
--The Chance to Work is maxed until 32 Missiles before decreasing Quadratically: ((math.random()<math.min((ammoPrintValue%1),(31/ship:GetMissileCount())^6))
--The Chance to Work is Maxed until 32 Missiles before decreasing Linearly, stopping at 40 (does it work?): ((math.random()<math.min((ammoPrintValue%1),(40-ship:GetMissileCount())/8))
