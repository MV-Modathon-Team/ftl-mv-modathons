function EffectBoost(projectile,weapon_or_drone)
    local augValue = weapon_or_drone.iShipId ~=-1 and  Hyperspace.ships(weapon_or_drone.iShipId):GetAugmentationValue("IPS_EFFECT_BOOST") or 0
    if projectile then
        local damage = projectile.damage
        damage.breachChance = damage.breachChance > 0 and damage.breachChance + augValue or damage.breachChance
        damage.fireChance = damage.fireChance > 0 and damage.fireChance + augValue or damage.fireChance
        damage.stunChance = damage.stunChance > 0 and damage.stunChance + augValue or damage.stunChance
    end
end
script.on_internal_event(Defines.InternalEvents.PROJECTILE_FIRE,
function(Projectile, Weapon)
    EffectBoost(Projectile,Weapon)
end)
script.on_internal_event(Defines.InternalEvents.DRONE_FIRE,
function(Projectile, Drone)
    EffectBoost(Projectile,Drone)
end)