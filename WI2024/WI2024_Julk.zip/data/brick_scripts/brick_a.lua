local animControl = Hyperspace.Animations
local SpaceManager = Hyperspace.Global.GetInstance():GetCApp().world.space
script.on_internal_event(Defines.InternalEvents.PROJECTILE_FIRE, function(proj, weapon)
    if weapon.blueprint.name=="ARTILLERY_BRICK" then
        for i=2,8 do
            local blast = SpaceManager:CreateLaserBlast(weapon.blueprint, proj.position, proj.currentSpace, proj.ownerId, proj.target, proj.destinationSpace, proj.heading)
            blast.entryAngle = proj.entryAngle
            blast.flight_animation = animControl:GetAnimation(proj.flight_animation.animName.."_"..i)
            --blast.speed_magnitude = proj.speed_magnitude * i
        end
        proj.flight_animation = animControl:GetAnimation(proj.flight_animation.animName.."_1")
    end
end)
script.on_internal_event(Defines.InternalEvents.JUMP_ARRIVE, function(ship)
    local arties = ship.artillerySystems
    if arties:size()>0 then
        for arty in mods.multiverse.vter(arties) do
            if arty.projectileFactory.blueprint.name=="ARTILLERY_BRICK" then
                arty.projectileFactory:ForceCoolup()
            end
        end
    end
end)


--SCRIPT.ON_INTERNAL_EVENT(dEFINES.iNTERNALeVENTS.projectile_fire, FUNCTION(PROJ, WEAPON) IF WEAPON.BLUEPRINT.NAME THEN LOCAL sPACEmANAGER = hYPERSPACE.gLOBAL.gETiNSTANCE():gETcaPP().WORLD.SPACE FOR I=1,5 DO LOCAL BLAST = sPACEmANAGER:cREATElASERbLAST(WEAPON.BLUEPRINT, PROJ.POSITION, PROJ.CURRENTsPACE, PROJ.OWNERiD, PROJ.TARGET, PROJ.DESTINATIONsPACE, PROJ.HEADING) BLAST.ENTRYaNGLE = PROJ.ENTRYaNGLE END END END)