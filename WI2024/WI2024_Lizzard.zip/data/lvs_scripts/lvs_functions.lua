brightless = {}

brightless.particleList = {}
local particleList = brightless.particleList
brightless.totalParticles = 0 --so the first particle starts as particleList[1]
local totalParticles = brightless.totalParticles
brightless.primitiveList = {}
local primitiveList = brightless.primitiveList

function brightless.create_particle(folder, frameCount, seconds, location, degrees, spaceValue, layer)
    totalParticles = totalParticles + 1
    local newParticle = {

    -------------------------
    -- Function arguments: --
    -------------------------

        spriteSheet = folder, --String
            --The file location of the FOLDER itself, where you'll have your sequential
            --png files named "0, 1, 2, 3..."
            --The "img/" at the front is automatically written by CreateImagePrimitiveString()
            --and should not be part of this.
        totalFrames = frameCount, --Int
            --This will be the amount of png files in your sprite folder folder for the particle.
            --i.e. take the final sprite's name and add 1.
            --The framerate of a particle is its "totalFrames" divided by its "lifetime"
        lifetime = seconds, --Float
            --The duration of the particle's animation. By default, it will self-delete when this
            --timer runs out.
        position = location, --Ints
            --Should be a Pointf value of the particle's X and Y coordinates.
        rotation = degrees, --Int
            --Rotation of the displayed frame in degrees.
        space = spaceValue,
            --0 if you want the particle to render on the player's plane, 1 for the enemy's.
        renderEvent = layer, --String
            --The RenderEvents callback that will render the particle.
            --i.e. when rendering a particle with SHIP_SPARKS, pass this as "SHIP_SPARKS"
            --Supported render layers are listed on the forum page.

    ---------------------------------------------------------------
    -- The following aren't arguments of create_particle; if you --
    -- want to use them, they're attributes of each particle.    --
    ---------------------------------------------------------------

        scale = 1, --Float
            --How large/small the image will be in relation to the png's size. (i.e. a scale value
            --of 0.5 will make a 20x20 image display as 10x10). Scaling is centered on the particle's
            --"position" attribute.
        movementSpeed = 0, --Float
            --How fast your particle will move across the screen in pixels-per-second. The direction of
            --movement is determined by the "heading" attribute below.
        heading = 0, --Float
            --This is completely separate from the rotation attribute. It refers to the
            --direction that the particle will travel if given a positive movementSpeed value.
            --Note: Lua's trig math functions will all return radian values. I don't prefer
            --radians, so I made this system around degrees :3 To pass a value of radians
            --into this system, use math.deg(). For consistency with "rotation," a heading of 0 points
            --directly upward.
        imageSpin = 0, --Float
            --A nonzero value will cause your particle to rotate around its center at the given speed.
            --Measured in degrees per second.
        headingSpin = 0, --Float
            --Similar to "imageSpin," but for the "heading" attribute. Causes particles to turn as
            --they move. Measured in degrees per second.
        persists = false, --Bool
            --Setting this to true will cause the particle to loop back to the beginning of its
            --animation each time it ends. You'll have to destroy_particle() yourself eventually,
            --or it'll be stuck on your screen (and taking up memory even it it drifts out of sight).
            --As this is a general-use library, I'll leave it up to you to delete persisting particles
            --after creating them :)
        countdown = 0, --Float
            --If set to a positive value, this will prevent the particle from rendering or updating for
            --that many seconds, effectively adding a delay before it appears.
        paused = false, --Bool
            --Setting this to true will freeze the particle's animation and expiration timer. You'll have
            --to keep track of a paused particle and unpause/destroy it yourself.
            --Pausing a particle during its "countdown" phase will freeze the countdown. If you want it to
            --pause *after* its countdown, set pauseOnFrame to 0
        pauseOnFrame = nil, --Int
            --Causes the particle to set "paused" to true when it reaches a certain frame.
            --i.e. a value of 3 will allow the particle to reach frame 4, then pause it.
            --When the animation reaches the desired frame, this attribute resets to nil.
        loops = 1,
            --Specifies how many times the animation should play. "Lifetime" defines ONE loop duration.
            --i.e. loops = 3, lifetime = 5 will cause the animation to play thrice over 15 seconds.
            --Does not decrement if "persists" is set to true.


    -------------------------------------------------------------------
    -- Internal-use attributes. I don't recommend messing with them. --
    -------------------------------------------------------------------
    
        currentFrame = 0, --Int
            --You'll have to change this every tick if you really want to for some reason.
        remainingDuration = seconds, --Float
        indexNum = totalParticles --Int. **Don't** tamper with this one
            --This should automatically hold the same value as the particle's index value in particleList[]
    }
    particleList[totalParticles] = newParticle
    return newParticle
end

function brightless.destroy_particle(particle)
    table.remove(particleList, particle.indexNum)
    totalParticles = totalParticles - 1
    local i = particle.indexNum
    while i <= totalParticles do
        particleList[i].indexNum = particleList[i].indexNum - 1
        i = i + 1
    end
end

function brightless.point_on_weapon_sprite(weapon, offsetX, offsetY)
    local emitPointX = 0
    local emitPointY = 0
    local rotate = false
    local mirror = false
    local vertMod = 1
    rotate = weapon.mount.rotate
    mirror = weapon.mount.mirror
    if mirror then vertMod = -1 end
    
    -- Calculate weapon coodinates
    local weaponAnim = weapon.weaponVisual
    local ship = Hyperspace.ships(weapon.iShipId).ship
    local shipGraph = Hyperspace.ShipGraph.GetShipInfo(weapon.iShipId)
    local slideOffset = weaponAnim:GetSlide()
    emitPointX = emitPointX + ship.shipImage.x + shipGraph.shipBox.x + weaponAnim.renderPoint.x + slideOffset.x
    emitPointY = emitPointY + ship.shipImage.y + shipGraph.shipBox.y + weaponAnim.renderPoint.y + slideOffset.y

    -- Add emitter and mount point offset
    if rotate then
        emitPointX = emitPointX - offsetY + weaponAnim.mountPoint.y
        emitPointY = emitPointY + (offsetX - weaponAnim.mountPoint.x)*vertMod
    else
        emitPointX = emitPointX + (offsetX - weaponAnim.mountPoint.x)*vertMod
        emitPointY = emitPointY + offsetY - weaponAnim.mountPoint.y
    end
    return Hyperspace.Pointf(emitPointX, emitPointY)
end

function brightless.offset_point_in_direction(point, heading, distance) --radius is half the height of the picture
    return Hyperspace.Pointf(point.x - (distance * math.cos(math.rad(heading))), point.y - (distance * math.sin(math.rad(heading))))
end

function brightless.random_offset_in_radius(point, radius)
    local offsetAngle = math.random(0,360)
    local offsetDistance = math.random(0,radius)
    return Hyperspace.Pointf(math.floor(point.x + offsetDistance * math.cos(math.rad(offsetAngle))), math.floor(point.y + offsetDistance * math.sin(math.rad(offsetAngle))))
end

local function game_is_paused()
    local commandGui = Hyperspace.Global.GetInstance():GetCApp().gui
    if commandGui.bPaused or commandGui.bAutoPaused or commandGui.event_pause or commandGui.menu_pause then
        return true
    else
        return false
    end
end

local function primitiveListManager(string)
    if not primitiveList[string] then
        local stringID = Hyperspace.Resources:GetImageId(string)
        primitiveList[string] = Hyperspace.Resources:CreateImagePrimitiveString(
            string,
            0 - stringID.width/2,
            0 - stringID.height/2,
            0,
            Graphics.GL_Color(1, 1, 1, 1),
            1.0,
            false
        )
    end
    return primitiveList[string]
end

local Brightless = brightless

local function handle_particles_on_layer(layer, ship)
    local i = 1
    while i <= totalParticles do
        local particle = particleList[i]

        if ship.iShipId == particle.space and particle.renderEvent == layer then
            if particle.countdown == 0 then
                Graphics.CSurface.GL_PushMatrix() --render current frame image
                Graphics.CSurface.GL_Translate(particle.position.x, particle.position.y, 0)
                Graphics.CSurface.GL_Rotate(particle.rotation, 0, 0, 1)
                Graphics.CSurface.GL_Scale(particle.scale, particle.scale, 1)
                Graphics.CSurface.GL_RenderPrimitive(primitiveListManager(particle.spriteSheet.."/"..tostring(particle.currentFrame)..".png"))
                Graphics.CSurface.GL_PopMatrix()
                if not(game_is_paused() or particle.paused) then --update timer and position
                    particle.remainingDuration = math.max(particle.remainingDuration - Hyperspace.FPS.SpeedFactor/16, 0)
                    particle.currentFrame = math.floor(((particle.lifetime - particle.remainingDuration) * particle.totalFrames) / particle.lifetime)
                    if particle.pauseOnFrame and particle.pauseOnFrame == particle.currentFrame then
                        particle.paused = true
                        particle.pauseOnFrame = nil
                    else
                        if particle.movementSpeed then
                            particle.position.x = particle.position.x + particle.movementSpeed*Hyperspace.FPS.SpeedFactor/16 * math.cos(math.rad(particle.heading + 270))
                            particle.position.y = particle.position.y + particle.movementSpeed*Hyperspace.FPS.SpeedFactor/16 * math.sin(math.rad(particle.heading + 270))
                        end
                        if particle.imageSpin then
                            particle.rotation = particle.rotation + math.floor(particle.imageSpin * Hyperspace.FPS.SpeedFactor/16)
                            --had to round to int value because GL_Rotate is a baby who doesn't know decimals yet
                        end
                        if particle.headingSpin then
                            particle.heading = particle.heading + particle.headingSpin * Hyperspace.FPS.SpeedFactor/16
                        end
                    end
                end
                --handle particle timer ending
                if particle.remainingDuration == 0 then
                    particle.remainingDuration = particle.lifetime
                    particle.currentFrame = 0
                    if not particle.persists then
                        particle.loops = particle.loops - 1
                    end
                    if particle.loops <= 0 then
                        Brightless.destroy_particle(particle)
                        i = i - 1
                    end
                end
            elseif not(game_is_paused() or particle.paused) then
                particle.countdown = math.max(particle.countdown - Hyperspace.FPS.SpeedFactor/16, 0)
            end
        end
        i = i + 1
    end
end

script.on_render_event(Defines.RenderEvents.SHIP, function() end, function(ship)
    handle_particles_on_layer("SHIP", ship)
end)

script.on_render_event(Defines.RenderEvents.SHIP_MANAGER, function() end, function(ship)
    handle_particles_on_layer("SHIP_MANAGER", ship)
end)

script.on_render_event(Defines.RenderEvents.SHIP_JUMP, function() end, function(ship)
    handle_particles_on_layer("SHIP_JUMP", ship)
end)

script.on_render_event(Defines.RenderEvents.SHIP_HULL, function() end, function(ship)
    handle_particles_on_layer("SHIP_HULL", ship)
end)

script.on_render_event(Defines.RenderEvents.SHIP_ENGINES, function() end, function(ship)
    handle_particles_on_layer("SHIP_ENGINES", ship)
end)

script.on_render_event(Defines.RenderEvents.SHIP_FLOOR, function() end, function(ship)
    handle_particles_on_layer("SHIP_FLOOR", ship)
end)

script.on_render_event(Defines.RenderEvents.SHIP_BREACHES, function() end, function(ship)
    handle_particles_on_layer("SHIP_BREACHES", ship)
end)

script.on_render_event(Defines.RenderEvents.SHIP_SPARKS, function() end, function(ship)
    handle_particles_on_layer("SHIP_SPARKS", ship)
end)

local function get_room_at_location(shipManager, location, includeWalls)
    return Hyperspace.ShipGraph.GetShipInfo(shipManager.iShipId):GetSelectedRoom(location.x, location.y, includeWalls)
end

local function gettileCount (shipManager, roomId)
    local shipGraph = Hyperspace.ShipGraph.GetShipInfo(shipManager.iShipId)

    return (shipGraph:GetRoomShape(roomId).w * shipGraph:GetRoomShape(roomId).h) / (35 * 35)
end

local function get_distance(point1, point2)
    return math.sqrt(((point2.x - point1.x)^2) + ((point2.y - point1.y)^2))
end

local function string_starts(str, start)
    return string.sub(str, 1, string.len(start)) == start
end
local function should_track_achievement(achievement, ship, shipClassName)
    return ship and
           Hyperspace.Global.GetInstance():GetCApp().world.bStartedGame and
           Hyperspace.CustomAchievementTracker.instance:GetAchievementStatus(achievement) < Hyperspace.Settings.difficulty and
           string_starts(ship.myBlueprint.blueprintName, shipClassName)
end

local function get_tile_centers(location, shape)
    local tile_centers = {}
    local tile_size = 35
    local tiles_x = math.floor(shape.w / tile_size)
    local tiles_y = math.floor(shape.h / tile_size)

    local half_width = (tiles_x * tile_size) / 2
    local half_height = (tiles_y * tile_size) / 2

    local start_x = location.x - half_width + tile_size / 2
    local start_y = location.y - half_height + tile_size / 2

    for i = 0, tiles_x - 1 do
        for j = 0, tiles_y - 1 do
            local tile_center_x = start_x + i * tile_size
            local tile_center_y = start_y + j * tile_size
            table.insert(tile_centers, {x = tile_center_x, y = tile_center_y})
        end
    end

    return tile_centers
end

local function get_room_line(shipId, roomId, direction)
    local shipGraph = Hyperspace.ShipGraph.GetShipInfo(shipId)
    local roomShape = shipGraph:GetRoomShape(roomId)
    local adjacentRooms = {}
    local currentRoom = nil

    local function check_for_room(x, y, i)
        currentRoom = shipGraph:GetSelectedRoom(x, y, false)
        if currentRoom > -1 and not adjacentRooms[currentRoom] then
            adjacentRooms[currentRoom] = Hyperspace.Pointf(x, y)
        end
    end

    if direction == 1 then
        for i = 0, 350, 35 do
            check_for_room(roomShape.x + i + 17, roomShape.y + 1, i)
        end
    elseif direction == 2 then
        for i = 0, 350, 35 do
            check_for_room(roomShape.x - i + 17, roomShape.y + 1, i)
        end
    elseif direction == 3 then
        for i = 0, 350, 35 do
            check_for_room(roomShape.x - 1, roomShape.y + i + 17, i)
        end
    elseif direction == 4 then
        for i = 0, 350, 35 do
            check_for_room(roomShape.x - 1, roomShape.y - i + 17, i)
        end
    else print("Yeah, man, I'll be honest: IDK how that even happened, but you rolled an impossible value on a D4")
    end
    return adjacentRooms

end

local function get_adjacent_rooms(shipId, roomId, diagonals)
    local shipGraph = Hyperspace.ShipGraph.GetShipInfo(shipId)
    local roomShape = shipGraph:GetRoomShape(roomId)
    local adjacentRooms = {}
    local currentRoom = nil
    local function check_for_room(x, y)
        currentRoom = shipGraph:GetSelectedRoom(x, y, false)
        if currentRoom > -1 and not adjacentRooms[currentRoom] then
            adjacentRooms[currentRoom] = Hyperspace.Pointf(x, y)
        end
    end
    for offset = 0, roomShape.w - 35, 35 do
        check_for_room(roomShape.x + offset + 17, roomShape.y - 17)
        check_for_room(roomShape.x + offset + 17, roomShape.y + roomShape.h + 17)
    end
    for offset = 0, roomShape.h - 35, 35 do
        check_for_room(roomShape.x - 17,               roomShape.y + offset + 17)
        check_for_room(roomShape.x + roomShape.w + 17, roomShape.y + offset + 17)
    end
    if diagonals then
        check_for_room(roomShape.x - 17,               roomShape.y - 17)
        check_for_room(roomShape.x + roomShape.w + 17, roomShape.y - 17)
        check_for_room(roomShape.x + roomShape.w + 17, roomShape.y + roomShape.h + 17)
        check_for_room(roomShape.x - 17,               roomShape.y + roomShape.h + 17)
    end
    return adjacentRooms
end

local function userdata_table(userdata, tableName)
    if not userdata.table[tableName] then userdata.table[tableName] = {} end
    return userdata.table[tableName]
end

local function vter(cvec)
    local i = -1
    local n = cvec:size()
    return function()
        i = i + 1
        if i < n then return cvec[i] end
    end
end

local function get_random_point_in_radius(center, radius)
    local r = radius * math.sqrt(math.random())
    local theta = math.random() * 2 * math.pi
    return Hyperspace.Pointf(math.floor(center.x + r * math.cos(theta)), math.floor(center.y + r * math.sin(theta)))
end

local function has_value (tab, val)
    for index, value in ipairs(tab) do
        if value == val then
            return true
        end
    end

    return false
end

local function get_point_local_offset(original, target, offsetForwards, offsetRight)
    local alpha = math.atan((original.y-target.y), (original.x-target.x))
    local newX = original.x - (offsetForwards * math.cos(alpha)) - (offsetRight * math.cos(alpha+math.rad(90)))
    local newY = original.y - (offsetForwards * math.sin(alpha)) - (offsetRight * math.sin(alpha+math.rad(90)))
    return Hyperspace.Pointf(newX, newY)
end

local function get_ship_crew_point(shipManager, x, y, maxCount)
    res = {}
    x = x//35
    y = y//35
    for crewmem in vter(shipManager.vCrewList) do
        if crewmem.iShipId == shipManager.iShipId and x == crewmem.x//35 and y == crewmem.y//35 then
            table.insert(res, crewmem)
            if maxCount and #res >= maxCount then
                return res
            end
        end
    end
    return res
end

local function closestCrew (hitmember, crewList, amount)
    local crewTarget = {hitmember}

    for i=1, amount do
        local closest = 1000
        local new = nil
        for crewmem in vter(crewList) do
            if not has_value(crewTarget, crewmem)  then
                local position = crewmem:GetPosition()
                local distance = get_distance(position, hitmember:GetPosition())
                if distance < closest then
                    new = crewmem
                end
            end
        end
        if new ~= nil then
            table.insert(crewTarget, new)
        end
    end

    return crewTarget
end

script.on_internal_event(Defines.InternalEvents.PROJECTILE_FIRE, function(projectile, weapon)
    local weaponName = weapon.blueprint.name

    if weaponName == "LV_ARTILLERY_FISSION" then
        Hyperspace.Sounds:PlaySoundMix("lv_fission", -1, false)
        local shipId = projectile.ownerId

        local shipManager = Hyperspace.Global.GetInstance():GetShipManager(shipId)

        local tabre = userdata_table(shipManager, "mods.lv.fission_boost")
        tabre.cd = 8

        local powerManager = Hyperspace.PowerManager.GetPowerManager(0)

        powerManager.batteryPower.first = 0
        powerManager.batteryPower.second = 5

        local weaponRoomID = shipManager:GetSystemRoom(3)

        local location = shipManager:GetRoomCenter(weaponRoomID)

        brightless.create_particle("particles/lv_booster", 18, 0.6, location, 0, shipManager.iShipId, "SHIP")

        local shieldRoomID = shipManager:GetSystemRoom(0)

        local ocation = shipManager:GetRoomCenter(shieldRoomID)

        brightless.create_particle("particles/lv_booster", 18, 0.6, ocation, 0, shipManager.iShipId, "SHIP")

        for weaponer in vter(shipManager:GetWeaponList()) do

            if weaponer.powered == true and weaponer.cooldown.first ~= weaponer.cooldown.second then

                if weaponer.cooldown.first + weaponer.cooldown.second * 0.5 >= weaponer.cooldown.second then
                    local newCooldownFirst = weaponer.cooldown.second - 0.3
                    weaponer.cooldown.first = math.min(newCooldownFirst, weaponer.cooldown.first + 9)
                else
                    local newCooldownFirst = weaponer.cooldown.first + weaponer.cooldown.second * 0.5
                    weaponer.cooldown.first = math.min(newCooldownFirst, weaponer.cooldown.first + 9)
                end

            end
        end

        shipManager.shieldSystem:InstantCharge()
        projectile:Kill()

    end

end)


script.on_internal_event(Defines.InternalEvents.SHIP_LOOP, function(shipManager)

    if shipManager:HasAugmentation("LV_FISSION") > 0 then
        if Hyperspace.ships.enemy == nil then
            return
        end
        if not Hyperspace.ships.enemy._targetable.hostile then return end
        local tabre = userdata_table(shipManager, "mods.lv.fission_damage")

        if tabre.cd == nil then

            local cd = math.random(20, 35)

            tabre.cd = cd
            tabre.anim = true

        end

    end

end)

script.on_internal_event(Defines.InternalEvents.SHIP_LOOP, function(shipManager)

    local tabred = userdata_table(shipManager, "mods.lv.fission_constant_damage")

    if tabred.cd == nil then

        tabred.cd = 4

    end

    if tabred.cd then
        tabred.cd = math.max(tabred.cd - Hyperspace.FPS.SpeedFactor/16, 0)

        local SysRoomId = shipManager:GetSystemRoom(11)
        for crewmem in vter(shipManager.vCrewList) do
            if crewmem.iRoomId == SysRoomId then
                crewmem:ModifyHealth(-0.05)
            end
        end

        if tabred.cd == 0 then

            tabred.cd = nil

        end
    end

    local tabre = userdata_table(shipManager, "mods.lv.fission_damage")
    if tabre.cd then

        if Hyperspace.ships.enemy == nil then
            tabre.cd = nil
            return
        end
        if not Hyperspace.ships.enemy._targetable.hostile then tabre.cd = nil return end

        tabre.cd = math.max(tabre.cd - Hyperspace.FPS.SpeedFactor/16, 0)

        if tabre.cd <= 3 then
            if tabre.anim == true then
                tabre.anim = false

                local SysRoomId = shipManager:GetSystemRoom(11)
                local SysLocation = shipManager:GetRoomCenter(SysRoomId)
                local shipGraph = Hyperspace.ShipGraph.GetShipInfo(shipManager.iShipId)
                local shape = shipGraph:GetRoomShape(SysRoomId)

                for _, tile_center in ipairs(get_tile_centers(SysLocation, shape)) do
                    local anim = brightless.create_particle("particles/lv_fis", 6, 3, Hyperspace.Pointf(tile_center.x, tile_center.y), 0, shipManager.iShipId, "SHIP_BREACHES")
                end

            end
        end

        if tabre.cd == 0 then

            tabre.cd = nil

            local SysRoomId = shipManager:GetSystemRoom(11)
            local SysLocation = shipManager:GetRoomCenter(SysRoomId)
            local sd = Hyperspace.Damage()

            for room in vter(shipManager.ship.vRoomList) do
                if room.iRoomId == SysRoomId then
                    room.extend.sysDamageResistChance = 0
                end
            end
            sd.iSystemDamage = 1
            shipManager:DamageArea(SysLocation, sd, true)

            Hyperspace.Sounds:PlaySoundMix("lv_rc_damage", -1, false)

            tabre.add_cd = 6

            local shipGraph = Hyperspace.ShipGraph.GetShipInfo(shipManager.iShipId)
            local shape = shipGraph:GetRoomShape(SysRoomId)

            for _, tile_center in ipairs(get_tile_centers(SysLocation, shape)) do
                local anim = brightless.create_particle("particles/lv_ffs", 1, 6, Hyperspace.Pointf(tile_center.x, tile_center.y), 0, shipManager.iShipId, "SHIP_BREACHES")
            end

        end
    end

    if tabre.add_cd then

        tabre.add_cd = math.max(tabre.add_cd - Hyperspace.FPS.SpeedFactor/16, 0)

        local SysRoomId = shipManager:GetSystemRoom(11)
        for crewmem in vter(shipManager.vCrewList) do
            if crewmem.iRoomId == SysRoomId then
                crewmem:ModifyHealth(-0.45)
            end
        end

        if tabre.add_cd == 0 then

            tabre.add_cd = nil

        end
    end

end)

script.on_internal_event(Defines.InternalEvents.SHIP_LOOP, function(shipManager)
    if shipManager:HasAugmentation("LV_FISSION") > 0 then

        local tabre = userdata_table(shipManager, "mods.lv.fission_death")

        if shipManager.artillerySystems[0].healthState.first == 0 and tabre.cd == nil then
            Hyperspace.Sounds:PlaySoundMix("lv_melt", -1, false)

            local SysRoomId = shipManager:GetSystemRoom(11)
            local SysLocation = shipManager:GetRoomCenter(SysRoomId)
            local shipGraph = Hyperspace.ShipGraph.GetShipInfo(shipManager.iShipId)
            local shape = shipGraph:GetRoomShape(SysRoomId)

            for _, tile_center in ipairs(get_tile_centers(SysLocation, shape)) do
                local anim = brightless.create_particle("particles/lv_mel", 8, 5, Hyperspace.Pointf(tile_center.x, tile_center.y), 0, shipManager.iShipId, "SHIP_BREACHES")
            end

            tabre.cd = 5

        end

        local roomer = shipManager:GetSystemRoom(11)
        for room in vter(shipManager.ship.vRoomList) do
            if room.iRoomId == roomer then
                room.extend.sysDamageResistChance = 100
                room.extend.ionDamageResistChance = 100
            end
        end

    end

    return Defines.Chain.CONTINUE
end)
script.on_internal_event(Defines.InternalEvents.SHIP_LOOP, function(shipManager)
    if shipManager:HasAugmentation("LV_FISSION") > 0 then

        local tabre = userdata_table(shipManager, "mods.lv.fission_death")
        if tabre.cd then

            tabre.cd = math.max(tabre.cd - Hyperspace.FPS.SpeedFactor/16, 0)

            if tabre.cd == 0 and shipManager.artillerySystems[0].healthState.first == 0 then

                tabre.cd = nil

                shipManager.ship.hullIntegrity.first = 0
                shipManager.ship.hullIntegrity.second = 0

            end
        end


    end

end)

local reacher = false

script.on_game_event("BOSS_TEXT_3", false, function()
    reacher = true
end)

script.on_game_event("DEATH", false, function()

    local shipManager = Hyperspace.Global.GetInstance():GetShipManager(0)

    if (should_track_achievement("ACH_SHIP_LV_SHADE_3", shipManager, "PLAYER_SHIP_LV_WI2024MODATHON")) and (reacher == true) then

        Hyperspace.CustomAchievementTracker.instance:SetAchievement("ACH_SHIP_LV_SHADE_3", false)

    end
end)

script.on_internal_event(Defines.InternalEvents.SHIP_LOOP, function(shipManager)

    if (should_track_achievement("ACH_SHIP_LV_SHADE_1", shipManager, "PLAYER_SHIP_LV_WI2024MODATHON")) then

        local least = Hyperspace.playerVariables["lvs_status"]

        if least > shipManager.artillerySystems[0].healthState.first then
            Hyperspace.playerVariables["lvs_status"] = shipManager.artillerySystems[0].healthState.first
        end

    end
end)

script.on_game_event("BOSS_TEXT_1", false, function()
    if (should_track_achievement("ACH_SHIP_LV_SHADE_1", shipManager, "PLAYER_SHIP_LV_WI2024MODATHON")) then

        if (Hyperspace.playerVariables["lvs_status"] > 1) then

            Hyperspace.CustomAchievementTracker.instance:SetAchievement("ACH_SHIP_LV_SHADE_1", false)

        end
    end
end)

local counterfit = 0
local missed_projectiles = {}

local function addToSet(set, key)
    set[key] = true
end

local function removeFromSet(set, key)
    set[key] = nil
end

local function setContains(set, key)
    return set[key] ~= nil
end

script.on_internal_event(Defines.InternalEvents.SHIP_LOOP, function(shipManager)

    local tabre = userdata_table(shipManager, "mods.lv.fission_boost")

    if tabre.cd then
        tabre.cd = math.max(tabre.cd - Hyperspace.FPS.SpeedFactor/16, 0)

        local spacerGuild = Hyperspace.Global.GetInstance():GetCApp().world.space

        --[[if (should_track_achievement("ACH_SHIP_LV_SHADE_2", shipManager, "PLAYER_SHIP_LV_WI2024MODATHON")) then

            for peoj in vter(spacerGuild.projectiles) do

                if peoj ~= nil then

                    if peoj.missed and not setContains(missed_projectiles, peoj) and not projectile:GetType() == 5 then

                        counterfit = counterfit + 1
                        addToSet(missed_projectiles, peoj)

                    end

                end

            end
        end]]--

        if tabre.cd == 0 then
            local powerManager = Hyperspace.PowerManager.GetPowerManager(0)
            powerManager.batteryPower.first = 0
            powerManager.batteryPower.second = 0

            tabre.cd = nil
            counterfit = 0
            missed_projectiles = {}
        end

    end

    if (should_track_achievement("ACH_SHIP_LV_SHADE_2", shipManager, "PLAYER_SHIP_LV_WI2024MODATHON")) and (counterfit >= 10) then

        Hyperspace.CustomAchievementTracker.instance:SetAchievement("ACH_SHIP_LV_SHADE_2", false)

    end

end)

script.on_internal_event(Defines.InternalEvents.GET_DODGE_FACTOR, function(shipManager, value)

    local tabre = userdata_table(shipManager, "mods.lv.fission_boost")

        if tabre.cd then
            value = math.min(99, math.ceil(value * 1.7))
        end

    return Defines.Chain.CONTINUE, value
end)

script.on_internal_event(Defines.InternalEvents.JUMP_LEAVE, function(shipManager)

    for i = #particleList, 1, -1 do
        if particleList[i].space == 1 then
            brightless.destroy_particle(particleList[i])
        end
    end

end)

script.on_internal_event(Defines.InternalEvents.JUMP_ARRIVE, function(shipManager)

    for i = #particleList, 1, -1 do
        if particleList[i].space == 1 then
            brightless.destroy_particle(particleList[i])
        end
    end

end)

script.on_internal_event(Defines.InternalEvents.ON_WAIT, function(shipManager)
    for i = #particleList, 1, -1 do
        if particleList[i].space == 1 then
            brightless.destroy_particle(particleList[i])
        end
    end

end)

script.on_game_event("DEATH", false, function()
    for i = #particleList, 1, -1 do
        if particleList[i].space == 1 then
            brightless.destroy_particle(particleList[i])
        end
    end
end)

script.on_game_event("START_BEACON", false, function()
    for i = #particleList, 1, -1 do
        if particleList[i].space == 1 then
            brightless.destroy_particle(particleList[i])
        end
    end
end)


local inHang = false

script.on_init(function() inHang = false end)
script.on_internal_event(Defines.InternalEvents.MAIN_MENU,function() inHang = true end)

script.on_game_event(Defines.InternalEvents.ON_TICK, false, function()
    if inHang == true then
        for i = #particleList, 1, -1 do
            if particleList[i].space == 1 then
                brightless.destroy_particle(particleList[i])
            end
        end
    end
end)
