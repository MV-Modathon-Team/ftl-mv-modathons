
local vter = mods.multiverse.vter
local userdata_table = mods.multiverse.userdata_table
local time_increment = mods.multiverse.time_increment
--Projectile Return
script.on_internal_event(Defines.InternalEvents.SHIP_LOOP, function(shipManager)
    if shipManager.iShipId == 0 then
        local projectiles = Hyperspace.App.world.space.projectiles
        if projectiles then
            for projectile in vter(projectiles) do
                --Stolen from Arc. Thanks Arc.
                local weaponName = nil
                pcall(function() weaponName = Hyperspace.Get_Projectile_Extend(projectile).name end)
                --Back to Original Code.
                if weaponName == "LASER_SELF_BOOMERANG" then
                    local timer = userdata_table(projectile, "mods.modathon.charger.boomerang").timer or 0
                    timer = timer + time_increment()
                    if timer > .5 and not userdata_table(projectile, "mods.modathon.charger.boomerang").returning then
                        --Return to sender (uh oh)
                        local playerShipGraph = Hyperspace.ShipGraph.GetShipInfo(0)
                        local projectileTarget = math.random(-1, playerShipGraph:RoomCount()-2) --unsure about this, but I'll put in the -1 anyways, better to never hit a room then to crash :/
                        --No targeting weapons.
                        --Weapons is room 11.
                        --0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19 Initial Scenario
                        --0,1,2,3,4,5,6,7,8,9,10,12,13,14,15,16,17,18,19 What we want
                        -- -1,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17 Starting Scenario
                        -- 0,1,2,3,4,5,6,7,8,9,10 | 12,13,14,15,16,17,18,19 Required Buffers
                        if projectileTarget<=9 then
                            projectileTarget = projectileTarget+1
                        else 
                            projectileTarget = projectileTarget+2
                        end

                        local target = Hyperspace.ships.player:GetRoomCenter(projectileTarget)
                        
                        userdata_table(projectile, "mods.modathon.charger.boomerang").returning = true
                        userdata_table(projectile, "mods.modathon.charger.boomerang").targetDirection = (projectile.heading + 180) % 360
                        projectile.targetId = 0
                        projectile.ownerId = 1
                        projectile.destinationSpace = 0
                        projectile.target = target
                    end
                    userdata_table(projectile, "mods.modathon.charger.boomerang").timer = timer
                end
                
                if userdata_table(projectile, "mods.modathon.charger.boomerang").returning == true then
                    if userdata_table(projectile, "mods.modathon.charger.boomerang").targetDirection > projectile.heading then
                        projectile.heading = projectile.heading + time_increment()*240
                    end
                end
                
            end
        end
    end
end)



script.on_internal_event(Defines.InternalEvents.DAMAGE_AREA_HIT, function(shipManager, projectile, location, damage, shipFriendlyFire)
    local weaponName = nil
    pcall(function() weaponName = Hyperspace.Get_Projectile_Extend(projectile).name end)
    if weaponName == "LASER_SELF_BOOMERANG" then
        Hyperspace.Get_Projectile_Extend(projectile).name = ""
        local actualDamage = Hyperspace.Damage()
        actualDamage.iDamage = 1
        shipManager:DamageArea(location, actualDamage, true)
        Hyperspace.Get_Projectile_Extend(projectile).name = weaponName
    end
    local augValue = shipManager:GetAugmentationValue("SELF_DAMAGE_CHARGER")
    if augValue > 0 then
        local weapons = shipManager:GetWeaponList()
        for weapon in vter(weapons) do
            if weapon.cooldown.first + 3 > weapon.cooldown.second then
                weapon.cooldown.first = weapon.cooldown.second - .1
            else 
                weapon.cooldown.first = weapon.cooldown.first + 3
            end
        end
    end
end)