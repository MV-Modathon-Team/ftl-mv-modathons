local vter = mods.multiverse.vter
local userdata_table = mods.multiverse.userdata_table
--space suits
local timeLimit = 7
local regenbuffer = 2
local whiteColour = Graphics.GL_Color(1,1,1,1)

local imageTable = {
    Hyperspace.Resources:GetImageId("people/breathbox.png"),
    Hyperspace.Resources:GetImageId("people/breathboxaquarter.png"),
    Hyperspace.Resources:GetImageId("people/breathboxhalf.png"),
    Hyperspace.Resources:GetImageId("people/breathboxthreequarters.png"),
    Hyperspace.Resources:GetImageId("people/breathboxfull.png")
}

script.on_internal_event(Defines.InternalEvents.CREW_LOOP, function(crew)

    --LOGIC
    local augValue = Hyperspace.ships.player:GetAugmentationValue("SPACE_SUITS")
    if augValue > 0 then
        --Create the Statboost to apply, will apply IS_ANAEROBIC, which prevents suffocation like setting can_suffocate to false so idk
        local statBoostManager = Hyperspace.StatBoostManager.GetInstance()
        local notAerobic = Hyperspace.StatBoostDefinition()
        local playerShipGraph = Hyperspace.ShipGraph.GetShipInfo(0)
        local enemyShipGraph  = Hyperspace.ShipGraph.GetShipInfo(1) or nil
        notAerobic.stat = Hyperspace.CrewStat.IS_ANAEROBIC
        notAerobic.boostType = Hyperspace.StatBoostDefinition.BoostType.SET
        notAerobic.boostSource = Hyperspace.StatBoostDefinition.BoostSource.AUGMENT
        notAerobic.shipTarget = Hyperspace.StatBoostDefinition.ShipTarget.ALL
        notAerobic.crewTarget = Hyperspace.StatBoostDefinition.CrewTarget.ORIGINAL_ALLIES
        notAerobic.duration = 1
        notAerobic.value = true
        notAerobic.isBool = true
        notAerobic.realBoostId = Hyperspace.StatBoostDefinition.statBoostDefs:size()
        Hyperspace.StatBoostDefinition.statBoostDefs:push_back(notAerobic)

        local time = userdata_table(crew, "mods.modathon.breacher.spacesuit").timer or 0
        local buffertime = userdata_table(crew, "mods.modathon.breacher.spacesuit").buffertimer or 0

        --Check if the crew needs to be provided with the statboost, only used for graphics
        --local _, canSuffocate = crew.extend:CalculateStat(Hyperspace.CrewStat.IS_ANAEROBIC)
        local canSuffocate = crew:CanSuffocate()
        if not canSuffocate then
            userdata_table(crew, "mods.modathon.breacher.spacesuit").needsSpaceSuit = false
        else
            userdata_table(crew, "mods.modathon.breacher.spacesuit").needsSpaceSuit = true
        end
        --Oxygen Logic. Find the room the crew is in and detect oxygen, and give the statboost if we need to, otherwise start a timer buffer for refilling oxygen.
        if crew.iShipId == 0 and not crew.intruder then
            if playerShipGraph:GetRoomOxygen(crew.iRoomId) <= .05 then
                if time < timeLimit then
                    statBoostManager:CreateTimedAugmentBoost(Hyperspace.StatBoost(notAerobic), crew)
                    time = time + mods.multiverse.time_increment()
                    buffertime = 0
                end
            end
            if playerShipGraph:GetRoomOxygen(crew.iRoomId) > .05 then
                if buffertime >= regenbuffer then
                    if time > 0 then
                        time = time - mods.multiverse.time_increment()
                    end
                elseif buffertime < regenbuffer then
                    buffertime = buffertime + (mods.multiverse.time_increment())
                end
            end
        end

        if crew.iShipId == 0 and crew.intruder then
            if enemyShipGraph:GetRoomOxygen(crew.iRoomId) <= .05 then
                if time < timeLimit then
                    statBoostManager:CreateTimedAugmentBoost(Hyperspace.StatBoost(notAerobic), crew)
                    time = time + mods.multiverse.time_increment()
                    buffertime = 0
                end
            end
            if enemyShipGraph:GetRoomOxygen(crew.iRoomId) > .05 then
                if buffertime >= regenbuffer then
                    if time > 0 then
                        time = time - mods.multiverse.time_increment()
                    end
                elseif buffertime < regenbuffer then
                    buffertime = buffertime + (mods.multiverse.time_increment())
                end
            end
        end
        userdata_table(crew, "mods.modathon.breacher.spacesuit").timer = time
        userdata_table(crew, "mods.modathon.breacher.spacesuit").buffertimer = buffertime
    end
end)

STATIC_Y = 2
STATIC_X = 3
--Holy fricking crap thank you pepson with the last hour fix. We have graphics!!!!!!
script.on_render_event(Defines.RenderEvents.CREW_MEMBER_HEALTH, function(crew)
    --GRAPHICS
    local time = userdata_table(crew, "mods.modathon.breacher.spacesuit").timer or 0
    if userdata_table(crew, "mods.modathon.breacher.spacesuit").needsSpaceSuit and crew.iShipId == 0 then
        local index = 5
        if time >= timeLimit then
            index = 1
        elseif time > timeLimit*3/4 then
            index = 2
        elseif time > timeLimit/2 then
            index = 3
        elseif time > timeLimit/4 then
            index = 4
        end

        Hyperspace.Resources:RenderImage(
            imageTable[index],
            math.floor(crew.x + crew.width/2 - 30),
            math.floor(crew.y + 10),
            0,
            whiteColour,
            1.0,
            false)
    end
end, function() end)