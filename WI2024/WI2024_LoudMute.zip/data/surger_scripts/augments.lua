local vter = mods.multiverse.vter

script.on_game_event("SURGER_CHECK", false, function()
    if Hyperspace.ships.enemy then --Check for enemy ship or might crash
        local playerShip = Hyperspace.ships.player
        local enemyShip = Hyperspace.ships.enemy
        local enemyShipGraph = Hyperspace.ShipGraph.GetShipInfo(1)
        local zsPower = playerShip:GetShieldPower().super.first
        local blueprintManager = Hyperspace.Global.GetInstance():GetBlueprints()
        local soundController = Hyperspace.Global.GetInstance():GetSoundControl()
        local shipCenter = playerShip.ship.baseEllipse.center
        local shipCenterPointf = Hyperspace.Pointf(shipCenter.x+(playerShip.ship.shipImage.w)/2, shipCenter.y+(playerShip.ship.shipImage.h)/2)
        if zsPower > 0 then
            local damage = Hyperspace.Damage()
            damage.iDamage = zsPower
            for i = 0, zsPower do --one bonus projectile, may change in the future (coding error that works lmao)
                local projectileType = math.random()
                local projectileTarget = math.random(0, enemyShipGraph:RoomCount()-1) --unsure about this, but I'll put in the -1 anyways, better to never hit a room then to crash :/
                local target = enemyShip:GetRoomCenter(projectileTarget)
                local projectile = nil
                if projectileType < .5 then -- Defense Laser
                    projectile = Hyperspace.App.world.space:CreateLaserBlast(blueprintManager:GetWeaponBlueprint("LASER_BURST_3"), shipCenterPointf, 0, 0, target, 1, 360*math.random())
                elseif projectileType < .75 then -- Heavy Laser
                    projectile = Hyperspace.App.world.space:CreateLaserBlast(blueprintManager:GetWeaponBlueprint("LASER_HEAVY_1"), shipCenterPointf, 0, 0, target, 1, 360*math.random())
                else -- Hull Laser
                    projectile = Hyperspace.App.world.space:CreateLaserBlast(blueprintManager:GetWeaponBlueprint("LASER_HULL_1"), shipCenterPointf, 0, 0, target, 1, 360*math.random())
                end
            end
            Hyperspace.ships.player.shieldSystem:CollisionReal(0,0,damage, true)
            --TODO play sounds
            soundController:PlaySoundMix("flak", 1, false)



        end
    end
end)
