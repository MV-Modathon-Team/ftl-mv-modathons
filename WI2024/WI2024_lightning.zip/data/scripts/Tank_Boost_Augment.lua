local damagesTakenThisBeacon = 0
local hullIntegrityLastCheck = -1

local shieldBuffValue = 0.2
local weaponsBuffValue = 0.2


-- reset damages each jump 
script.on_internal_event(Defines.InternalEvents.JUMP_LEAVE, function(ship)
    if ship:HasAugmentation("LIGHTNING_AI_TANK_BOOST") then
        damagesTakenThisBeacon = 0
    end
end)


script.on_internal_event(Defines.InternalEvents.PROJECTILE_FIRE, function(projectile, weapon)
    if Hyperspace.ships.player:HasAugmentation("LIGHTNING_AI_TANK_BOOST") > 0 then

        -- Only adjust ennemi projectiles
        if projectile.ownerId == 1 then

            -- Beams need special logic
            if projectile:GetType() == 5 then 
                local currentShieldPower = Hyperspace.ships.player:GetShieldPower().first

                -- Need to take into account beams with shield piercing properties
                local effectiveShieldPower = math.max(0, currentShieldPower - projectile.damage.iShieldPiercing)

                local damageAfterShieldReduction = projectile.damage.iDamage - effectiveShieldPower

                -- Only adjust their damages if they still do too much
                if damageAfterShieldReduction > 1 then
                    projectile.damage.iDamage = effectiveShieldPower + 1
                end
             
            else
                local incomingDamage = projectile.damage.iDamage
                if incomingDamage > 1 then
                    projectile.damage.iDamage = 1
                end
            end

            -- Also setting hull burst to false to avoid double damages on empty rooms
            projectile.damage.bHullBuster = false 
        end
    end
end)


script.on_internal_event(Defines.InternalEvents.SHIP_LOOP, function(ship)
    if ship:HasAugmentation("LIGHTNING_AI_TANK_BOOST") > 0 then

        -- Initialize ship's current health when a run is lunched.
        -- (I tried to do it in a script.on_init function but I can't figure out how to get the hullIntegrity from there. So it'll stay here and do a useless check every frame except for the first one :/ )
        if hullIntegrityLastCheck == -1 then 
            hullIntegrityLastCheck = ship.ship.hullIntegrity.first
        end


        -- Checking if damages were taken this frame
        local currentHullIntegrity = ship.ship.hullIntegrity.first
        if hullIntegrityLastCheck > currentHullIntegrity then -- Took damages
            damagesTakenThisBeacon = damagesTakenThisBeacon + (hullIntegrityLastCheck - currentHullIntegrity)
            --print("damagesTakenThisBeacon:", damagesTakenThisBeacon)
        end
        -- Important to update hullIntegrityLastCheck out of the above 'if' or else it's not updated when we heal the ship
        hullIntegrityLastCheck = currentHullIntegrity


        -- Need to re-adjust ennemies beams damages each frames (cause we can either gain or lose shield layers thus changing how many damages would be dealt)
        local projectiles = Hyperspace.App.world.space.projectiles
        for projectile in mods.multiverse.vter(projectiles) do

            if projectile.ownerId == 1 then 

                if projectile:GetType() == 5 then 
                    local currentShieldPower = ship:GetShieldPower().first

                    local effectiveShieldPower = math.max(0, currentShieldPower - projectile.damage.iShieldPiercing)

                    -- Using these two to get back the beam original damage through it's blueprint
                    local beamWeaponBlueprintName = Hyperspace.Get_Projectile_Extend(projectile).name
                    local beamWeaponBlueprint = Hyperspace.Blueprints:GetWeaponBlueprint(beamWeaponBlueprintName)

                    -- I need to use the weapon blueprint base damages to calculate if beam is still piercing
                    local damageAfterShieldReduction = beamWeaponBlueprint.damage.iDamage - effectiveShieldPower 
                    
                    -- This line 'reset' the beam damage to avoid not doing any damages next check is some shield layer was gained
                    projectile.damage.iDamage = beamWeaponBlueprint.damage.iDamage

                    if damageAfterShieldReduction > 1 then
                        projectile.damage.iDamage = effectiveShieldPower + 1
                        --print(Hyperspace.Get_Projectile_Extend(projectile).name, "damages ajusted to", currentShieldPower + 1)
                    end

                    -- No need to re check lasers/missiles/bombs... those were already adjusted
                
                end
            end
        end
    end
end)


-- Messing around with the shield recharge rate and weapons reload speed
script.on_internal_event(Defines.InternalEvents.GET_AUGMENTATION_VALUE, function(shipManager, augName, augValue)
    if shipManager:HasAugmentation("LIGHTNING_AI_TANK_BOOST") > 0 then
        
        -- Shield recharge rate
        if augName == "SHIELD_RECHARGE" then
            augValue = augValue + (shieldBuffValue * damagesTakenThisBeacon)
        end

        -- Weapons reload speed
        if augName == "AUTO_COOLDOWN" then
            augValue = augValue + (weaponsBuffValue * damagesTakenThisBeacon)
        end

    end
    return Defines.Chain.CONTINUE, augValue
end)