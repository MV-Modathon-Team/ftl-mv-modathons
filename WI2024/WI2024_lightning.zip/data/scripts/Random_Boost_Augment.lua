-- This value will determine wich buff/debuff to apply
local randomBoostAugmentValue = 0 --Maybe initialize this value as -1 to avoid messing with shield/weapons on ship that don't have this augment, need to test. if needs to, add a if == -1 before the others checks for shield/weapons

--[[ According to randomBoostAugmentValue, which system to buff/debuff?

RBAValue:      0.33            0.66
Engine  : [UP]      [Neutral]       [Down]
Shield  : [DOWN]      [UP]       [NEUTRAL]
Weapons : [NEUTRAL]  [DOWN]           [UP]

]]--

-- Values for buff/debuff for each system and their fluctuations
-- Engin values -> [0-100]
local engineBuffValue = 20
local engineBuffFluctuationValue = 10
local engineDebuffValue = -10
local engineDebuffFluctuationValue = 10
local engineNeutralFluctuationValue = 10

--[[

-- Shield values -> [0-1]
local shieldBuffValue = 0.3
local shieldBuffFluctuationValue = 0.15
local shieldDebuffValue = -0.4
local shieldDebuffFluctuationValue = 0.2
local shieldNeutralFluctuationValue = 0.15

-- Weapons values -> [0-1]
local weaponsBuffValue = 0.3
local weaponsBuffFluctuationValue = 0.1
local weaponsDebuffValue = -0.2
local weaponsDebuffFluctuationValue = 0.1
local weaponsNeutralFluctuationValue = 0.1

]]--


-- Get a new randomBoostAugmentValue at each jump
script.on_internal_event(Defines.InternalEvents.JUMP_LEAVE, function(ship)
    if ship:HasAugmentation("LIGHTNING_AI_RANDOM_BOOST") then
        randomBoostAugmentValue = math.random()
        --print("randomBoostAugmentValue: ", randomBoostAugmentValue)
    end
end)


-- Messing around with the dodge chances (Engine)
script.on_internal_event(Defines.InternalEvents.GET_DODGE_FACTOR, function(ship, value)
    if ship:HasAugmentation("LIGHTNING_AI_RANDOM_BOOST") then
        if value > 0 then -- I don't want to give a boost if there is no power / engines are hacked
            if randomBoostAugmentValue < 0.33 then -- Buff
                --print("Buff")
                value = value + engineBuffValue + random_float(-engineBuffFluctuationValue, engineBuffFluctuationValue)
                --print("Value:", value)
            elseif randomBoostAugmentValue > 0.66 then -- Debuff
                --print("DEBUFF")
                value = math.max(0, value + engineDebuffValue + random_float(-engineDebuffFluctuationValue, engineDebuffFluctuationValue))
                --print("value:", value)
            else -- Neutral
                --print("NEUTRAL")
                value = math.max(0, value + random_float(-engineNeutralFluctuationValue, engineNeutralFluctuationValue))
                --print("value:", value)
            end
        end
    end
    return Defines.Chain.CONTINUE, value
end)


--[[ I'd need a way to only modify the player ship, don't know if I can add a check like for the engine. Right now, it also apply these to the ennemi ship and I don't want that

-- Messing around with the shield recharge rate and weapons reload speed
script.on_internal_event(Defines.InternalEvents.GET_AUGMENTATION_VALUE, function(shipManager, augName, augValue)
    if shipManager then

        -- Shield recharge rate
        if augName == "SHIELD_RECHARGE" then
            if randomBoostAugmentValue < 0.33 then -- Debuff
                augValue = math.max(0.2, augValue + shieldDebuffValue + random_float(-shieldDebuffFluctuationValue, shieldDebuffFluctuationValue)) -- adding a math.max(0.2, ...) to cap debuff to 20% base speed at min (wouldn't want to completly disable them)
            
            elseif randomBoostAugmentValue > 0.66 then -- Neutral
                augValue = math.max(0.2, augValue + random_float(-shieldNeutralFluctuationValue, shieldNeutralFluctuationValue))
            
            else -- Buff
                augValue = augValue + shieldBuffValue + random_float(-shieldBuffFluctuationValue, shieldBuffFluctuationValue)
            
            end
        end

        -- Weapons reload speed
        if augName == "AUTO_COOLDOWN" then
            if randomBoostAugmentValue < 0.33 then -- Neutral
                augValue = math.max(0.2, augValue + random_float(-weaponsNeutralFluctuationValue, weaponsNeutralFluctuationValue))
            
            elseif randomBoostAugmentValue > 0.66 then -- Buff
                augValue = augValue + weaponsBuffValue + random_float(-weaponsBuffFluctuationValue, weaponsBuffFluctuationValue)
            
            else -- Debuff
                augValue = math.max(0.2, augValue + weaponsDebuffValue + random_float(-weaponsDebuffFluctuationValue, weaponsDebuffFluctuationValue))
            
            end
        end

    end
    return Defines.Chain.CONTINUE, augValue
end)

]]--

-- Need a custom function since math.random(x, y) only takes integers
function random_float(x, y)
    return x + (y - x) * math.random()
end